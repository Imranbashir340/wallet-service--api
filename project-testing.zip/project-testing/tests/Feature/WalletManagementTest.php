<?php

namespace Tests\Feature;

use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;
use App\Models\Wallet;

class WalletManagementTest extends TestCase
{
    use RefreshDatabase;

    /**
     * Requirement: POST /wallets Create a wallet with owner_name and currency. Starts with zero balance.
     */
    public function test_create_wallet_successfully()
    {
        $response = $this->postJson('/api/wallets', [
            'owner_name' => 'Alice',
            'currency' => 'USD',
        ]);

        $response->assertStatus(201)
            ->assertJson([
                'owner_name' => 'Alice',
                'currency' => 'USD',
                'balance' => 0,
            ]);

        $this->assertDatabaseHas('wallets', [
            'owner_name' => 'Alice',
            'currency' => 'USD',
            'balance' => 0,
        ]);
    }

    public function test_create_wallet_validation_errors()
    {
        $response = $this->postJson('/api/wallets', []);

        $response->assertStatus(422)
            ->assertJsonValidationErrors(['owner_name', 'currency']);
    }

    /**
     * Requirement: GET /wallets/{id} Retrieve wallet details including current balance.
     */
    public function test_retrieve_wallet_details()
    {
        $wallet = Wallet::factory()->create([
            'owner_name' => 'Bob',
            'currency' => 'EUR',
            'balance' => 100,
        ]);

        $response = $this->getJson("/api/wallets/{$wallet->id}");

        $response->assertStatus(200)
            ->assertJson([
                'id' => $wallet->id,
                'owner_name' => 'Bob',
                'currency' => 'EUR',
                'balance' => 100,
            ]);
    }

    public function test_retrieve_non_existent_wallet()
    {
        $response = $this->getJson("/api/wallets/999");

        $response->assertStatus(404);
    }

    /**
     * Requirement: GET /wallets List all wallets. Optional filters for owner or currency.
     */
    public function test_list_all_wallets()
    {
        Wallet::factory()->count(3)->create();

        $response = $this->getJson('/api/wallets');

        $response->assertStatus(200)
            ->assertJsonCount(3);
    }

    public function test_list_wallets_filter_by_owner()
    {
        Wallet::factory()->create(['owner_name' => 'Charlie']);
        Wallet::factory()->create(['owner_name' => 'David']);

        $response = $this->getJson('/api/wallets?owner_name=Charlie');

        $response->assertStatus(200)
            ->assertJsonCount(1)
            ->assertJsonFragment(['owner_name' => 'Charlie'])
            ->assertJsonMissing(['owner_name' => 'David']);
    }

    public function test_list_wallets_filter_by_currency()
    {
        Wallet::factory()->create(['currency' => 'USD']);
        Wallet::factory()->create(['currency' => 'GBP']);

        $response = $this->getJson('/api/wallets?currency=USD');

        $response->assertStatus(200)
            ->assertJsonCount(1)
            ->assertJsonFragment(['currency' => 'USD'])
            ->assertJsonMissing(['currency' => 'GBP']);
    }
}
