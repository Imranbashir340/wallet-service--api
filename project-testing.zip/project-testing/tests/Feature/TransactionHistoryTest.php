<?php

namespace Tests\Feature;

use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;
use App\Models\Wallet;
use App\Models\Transaction;

class TransactionHistoryTest extends TestCase
{
    use RefreshDatabase;

    /**
     * Requirement: GET /wallets/{id}/transactions Return chronological list of all wallet transactions.
     * Includes ID, type, amount, related wallets, and timestamp.
     */
    public function test_list_transactions()
    {
        $wallet = Wallet::factory()->create();
        
        // Create 3 transactions
        Transaction::factory()->create(['wallet_id' => $wallet->id, 'created_at' => now()->subDays(1)]);
        Transaction::factory()->create(['wallet_id' => $wallet->id, 'created_at' => now()]);
        Transaction::factory()->create(['wallet_id' => $wallet->id, 'created_at' => now()->subDays(2)]);

        $response = $this->getJson("/api/wallets/{$wallet->id}/transactions");

        $response->assertStatus(200)
            ->assertJsonCount(3, 'data') // Assuming pagination wraps data
            ->assertJsonStructure([
                'data' => [
                    '*' => ['id', 'type', 'amount', 'created_at'] // Checking core structure
                ]
            ]);
    }

    /**
     * Requirement: Filters (type).
     */
    public function test_list_transactions_filter_by_type()
    {
        $wallet = Wallet::factory()->create();
        Transaction::factory()->create(['wallet_id' => $wallet->id, 'type' => 'deposit']);
        Transaction::factory()->create(['wallet_id' => $wallet->id, 'type' => 'withdrawal']);

        $response = $this->getJson("/api/wallets/{$wallet->id}/transactions?type=deposit");

        $response->assertStatus(200)
            ->assertJsonCount(1, 'data')
            ->assertJsonFragment(['type' => 'deposit'])
            ->assertJsonMissing(['type' => 'withdrawal']);
    }

    /**
     * Requirement: Filters (date range).
     */
    public function test_list_transactions_filter_by_date_range()
    {
        $wallet = Wallet::factory()->create();
        $t1 = Transaction::factory()->create(['wallet_id' => $wallet->id, 'created_at' => '2023-01-10 10:00:00']);
        $t2 = Transaction::factory()->create(['wallet_id' => $wallet->id, 'created_at' => '2023-01-15 10:00:00']);
        $t3 = Transaction::factory()->create(['wallet_id' => $wallet->id, 'created_at' => '2023-01-20 10:00:00']);

        // Filter from 12th to 18th (should only include t2)
        $url = "/api/wallets/{$wallet->id}/transactions?from=2023-01-12&to=2023-01-18";
        $response = $this->getJson($url);

        $response->assertStatus(200)
            ->assertJsonCount(1, 'data')
            ->assertJsonFragment(['id' => $t2->id])
            ->assertJsonMissing(['id' => $t1->id])
            ->assertJsonMissing(['id' => $t3->id]);
    }

    /**
     * Requirement: Pagination.
     */
    public function test_list_transactions_pagination()
    {
        $wallet = Wallet::factory()->create();
        Transaction::factory()->count(25)->create(['wallet_id' => $wallet->id]);

        $response = $this->getJson("/api/wallets/{$wallet->id}/transactions?page=1");

        $response->assertStatus(200)
            ->assertJsonCount(20, 'data') // Default pagination 20
            ->assertJsonStructure(['current_page', 'last_page', 'total']); // Standard Laravel pagination
    }
}
