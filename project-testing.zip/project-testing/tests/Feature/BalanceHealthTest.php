<?php

namespace Tests\Feature;

use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;
use App\Models\Wallet;

class BalanceHealthTest extends TestCase
{
    use RefreshDatabase;

    /**
     * Requirement: GET /wallets/{id}/balance Returns the current wallet balance.
     */
    public function test_get_wallet_balance()
    {
        $wallet = Wallet::factory()->create(['balance' => 5000]);

        $response = $this->getJson("/api/wallets/{$wallet->id}/balance");

        $response->assertStatus(200)
            ->assertJson(['balance' => 5000]);
    }

    /**
     * Requirement: GET /health Returns { "status": "ok" }.
     */
    public function test_health_check_returns_ok()
    {
        $response = $this->getJson('/api/health');

        $response->assertStatus(200)
            ->assertJson(['status' => 'ok']);
    }

    /**
     * Requirement: Transfers only allowed between same-currency wallets.
     * Note: This was partially tested in TransferTest, but adding a specific test here reinforces the currency rule requirement.
     */
    public function test_transfer_fails_different_currencies()
    {
        $source = Wallet::factory()->create(['currency' => 'USD', 'balance' => 1000]);
        $target = Wallet::factory()->create(['currency' => 'GBP', 'balance' => 1000]);

        $response = $this->postJson('/api/transfers', [
            'from_wallet_id' => $source->id,
            'to_wallet_id' => $target->id,
            'amount' => 100
        ]);

        $response->assertStatus(400); // Expecting abort(400, 'Currency mismatch')
    }
}
