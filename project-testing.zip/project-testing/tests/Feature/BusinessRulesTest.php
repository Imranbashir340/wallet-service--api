<?php

namespace Tests\Feature;

use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;
use App\Models\Wallet;
use App\Models\Transaction;

class BusinessRulesTest extends TestCase
{
    use RefreshDatabase;

    /**
     * Rule: Negative amounts are invalid for deposits/withdrawals/transfers.
     * (Implicit in "Accepts amount" but critically "min:1" or positive check)
     */
    public function test_cannot_transact_negative_amounts()
    {
        $wallet = Wallet::factory()->create(['balance' => 1000]);

        // Deposit negative
        $this->postJson("/api/wallets/{$wallet->id}/deposit", ['amount' => -100])
            ->assertStatus(422);

        // Withdraw negative
        $this->postJson("/api/wallets/{$wallet->id}/withdraw", ['amount' => -100])
             ->assertStatus(422);

        // Transfer negative
        $target = Wallet::factory()->create();
        $this->postJson('/api/transfers', [
            'from_wallet_id' => $wallet->id,
            'to_wallet_id' => $target->id,
            'amount' => -100
        ])->assertStatus(422);
    }

    /**
     * Rule: Insufficient Funds. Wallet balance cannot go below zero (except maybe via force, but business rule usually implies >= 0).
     */
    public function test_wallet_balance_cannot_be_negative()
    {
        $wallet = Wallet::factory()->create(['balance' => 50]);

        // Attempt to withdraw 100 (more than balance)
        $this->postJson("/api/wallets/{$wallet->id}/withdraw", ['amount' => 100])
             ->assertStatus(400); // Bad Request

        // Ensure balance is still 50, not -50
        $this->assertDatabaseHas('wallets', ['id' => $wallet->id, 'balance' => 50]);
    }

    /**
     * Rule: Self-Transfer forbidden.
     */
    public function test_cannot_transfer_to_self()
    {
        $wallet = Wallet::factory()->create(['balance' => 1000]);

        $this->postJson('/api/transfers', [
            'from_wallet_id' => $wallet->id,
            'to_wallet_id' => $wallet->id,
            'amount' => 100
        ])->assertStatus(422); // Validation error
    }

    /**
     * Rule: Currency Consistency. Transfers only between same-currency wallets.
     */
    public function test_cross_currency_transfer_forbidden()
    {
        $usdWallet = Wallet::factory()->create(['currency' => 'USD', 'balance' => 1000]);
        $eurWallet = Wallet::factory()->create(['currency' => 'EUR', 'balance' => 1000]);

        $this->postJson('/api/transfers', [
            'from_wallet_id' => $usdWallet->id,
            'to_wallet_id' => $eurWallet->id,
            'amount' => 100
        ])->assertStatus(400); // "Currency mismatch"
    }

    /**
     * Rule: Idempotency. Repeated requests with same key must not duplicate transactions.
     * (Critical for financial integrity)
     */
    public function test_idempotency_prevents_double_spending()
    {
        $wallet = Wallet::factory()->create(['balance' => 1000]);
        $key = 'biz-rule-key-999';

        // 1st Withdraw
        $this->postJson("/api/wallets/{$wallet->id}/withdraw", ['amount' => 100], ['Idempotency-Key' => $key])
            ->assertStatus(200);

        // 2nd Withdraw (SAME KEY)
        $this->postJson("/api/wallets/{$wallet->id}/withdraw", ['amount' => 100], ['Idempotency-Key' => $key])
            ->assertStatus(200);

        // Balance should correspond to ONE withdrawal (1000 - 100 = 900, NOT 800)
        $this->assertDatabaseHas('wallets', ['id' => $wallet->id, 'balance' => 900]);
    }
}
