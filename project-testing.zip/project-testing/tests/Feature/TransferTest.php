<?php

namespace Tests\Feature;

use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;
use App\Models\Wallet;
use App\Models\Transaction;

class TransferTest extends TestCase
{
    use RefreshDatabase;

    /**
     * Requirement: Transfers move funds atomically... Debit from source, Credit to target.
     */
    public function test_transfer_moves_funds_correctly()
    {
        $source = Wallet::factory()->create(['balance' => 1000, 'currency' => 'USD']);
        $target = Wallet::factory()->create(['balance' => 500, 'currency' => 'USD']);

        $response = $this->postJson('/api/transfers', [
            'from_wallet_id' => $source->id,
            'to_wallet_id' => $target->id,
            'amount' => 300
        ]);

        $response->assertStatus(200)
            ->assertJson(['message' => 'Transfer successful']);

        $this->assertDatabaseHas('wallets', ['id' => $source->id, 'balance' => 700]);
        $this->assertDatabaseHas('wallets', ['id' => $target->id, 'balance' => 800]);

        $this->assertDatabaseHas('transactions', [
            'wallet_id' => $source->id,
            'type' => 'transfer_debit',
            'amount' => 300,
            'related_wallet_id' => $target->id
        ]);

        $this->assertDatabaseHas('transactions', [
            'wallet_id' => $target->id,
            'type' => 'transfer_credit',
            'amount' => 300,
            'related_wallet_id' => $source->id
        ]);
    }

    /**
     * Requirement: Reject if insufficient balance.
     */
    public function test_transfer_fails_insufficient_funds()
    {
        $source = Wallet::factory()->create(['balance' => 100]);
        $target = Wallet::factory()->create(['balance' => 500]);

        $response = $this->postJson('/api/transfers', [
            'from_wallet_id' => $source->id,
            'to_wallet_id' => $target->id,
            'amount' => 200
        ]);

        $response->assertStatus(400);

        // Balances remain unchanged
        $this->assertDatabaseHas('wallets', ['id' => $source->id, 'balance' => 100]);
        $this->assertDatabaseHas('wallets', ['id' => $target->id, 'balance' => 500]);
    }

    /**
     * Requirement: Reject if self-transfer (different:target_wallet_id validation rule).
     */
    public function test_transfer_fails_self_transfer()
    {
        $wallet = Wallet::factory()->create(['balance' => 1000]);

        $response = $this->postJson('/api/transfers', [
            'from_wallet_id' => $wallet->id,
            'to_wallet_id' => $wallet->id,
            'amount' => 100
        ]);

        $response->assertStatus(422) // Validation error for 'different' rule
            ->assertJsonValidationErrors(['from_wallet_id']);
    }

    /**
     * Extra Check: Reject currency mismatch (implied by good design, explicitly coded in controller).
     */
    public function test_transfer_fails_currency_mismatch()
    {
        $source = Wallet::factory()->create(['currency' => 'USD', 'balance' => 1000]);
        $target = Wallet::factory()->create(['currency' => 'EUR', 'balance' => 500]);

        $response = $this->postJson('/api/transfers', [
            'from_wallet_id' => $source->id,
            'to_wallet_id' => $target->id,
            'amount' => 100
        ]);

        $response->assertStatus(400); // "Currency mismatch" abort
    }

    /**
     * Requirement: Idempotency required using Idempotency-Key.
     */
    public function test_transfer_is_idempotent()
    {
        $source = Wallet::factory()->create(['balance' => 1000, 'currency' => 'USD']);
        $target = Wallet::factory()->create(['balance' => 500, 'currency' => 'USD']);
        $key = 'transfer-key-789';

        // First transfer
        $this->postJson('/api/transfers', [
            'from_wallet_id' => $source->id,
            'to_wallet_id' => $target->id,
            'amount' => 300
        ], ['Idempotency-Key' => $key])->assertStatus(200);

        // Second transfer (SAME KEY)
        $this->postJson('/api/transfers', [
            'from_wallet_id' => $source->id,
            'to_wallet_id' => $target->id,
            'amount' => 300
        ], ['Idempotency-Key' => $key])->assertStatus(200);

        // Balance should change EXACTLY ONCE (Source: 1000 - 300 = 700)
        $this->assertDatabaseHas('wallets', ['id' => $source->id, 'balance' => 700]);
        $this->assertDatabaseHas('wallets', ['id' => $target->id, 'balance' => 800]);

        // Transactions should be created ONCE (pair)
        $this->assertDatabaseCount('transactions', 2); // 1 debit + 1 credit
    }
}
