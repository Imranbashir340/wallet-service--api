<?php

namespace Tests\Feature;

use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;
use App\Models\Wallet;
use App\Models\Transaction;

class DepositWithdrawalTest extends TestCase
{
    use RefreshDatabase;

    /**
     * Requirement: Deposit POST /wallets/{id}/deposit. Accepts amount. Adds funds.
     */
    public function test_deposit_adds_funds()
    {
        $wallet = Wallet::factory()->create(['balance' => 1000]);

        $response = $this->postJson("/api/wallets/{$wallet->id}/deposit", [
            'amount' => 500
        ]);

        $response->assertStatus(200)
            ->assertJson(['balance' => 1500]);

        $this->assertDatabaseHas('wallets', [
            'id' => $wallet->id,
            'balance' => 1500
        ]);

        $this->assertDatabaseHas('transactions', [
            'wallet_id' => $wallet->id,
            'type' => 'deposit',
            'amount' => 500
        ]);
    }

    /**
     * Requirement: Deposit Must be idempotent (Idempotency-Key header).
     */
    public function test_deposit_is_idempotent()
    {
        $wallet = Wallet::factory()->create(['balance' => 1000]);
        $key = 'unique-key-123';

        // First Request
        $this->postJson("/api/wallets/{$wallet->id}/deposit", ['amount' => 500], ['Idempotency-Key' => $key])
            ->assertStatus(200)
            ->assertJson(['balance' => 1500]);

        // Second Request (Should be ignored)
        $this->postJson("/api/wallets/{$wallet->id}/deposit", ['amount' => 500], ['Idempotency-Key' => $key])
            ->assertStatus(200) // Or 200/204, based on implementation returning current balance, usually just success
            ->assertJson(['balance' => 1500]);

        // Verify balance is only 1500 (1000 + 500 once)
        $this->assertDatabaseHas('wallets', [
            'id' => $wallet->id,
            'balance' => 1500
        ]);

        // Verify only 1 transaction exists for this key
        $this->assertDatabaseCount('transactions', 1);
    }

    public function test_deposit_validation()
    {
        $wallet = Wallet::factory()->create();

        $this->postJson("/api/wallets/{$wallet->id}/deposit", ['amount' => -100])
             ->assertStatus(422);

        $this->postJson("/api/wallets/{$wallet->id}/deposit", [])
             ->assertStatus(422);
    }

    /**
     * Requirement: Withdraw POST /wallets/{id}/withdraw. Accepts amount.
     */
    public function test_withdraw_removes_funds()
    {
        $wallet = Wallet::factory()->create(['balance' => 1000]);

        $response = $this->postJson("/api/wallets/{$wallet->id}/withdraw", [
            'amount' => 300
        ]);

        $response->assertStatus(200)
            ->assertJson(['balance' => 700]);

        $this->assertDatabaseHas('wallets', [
            'id' => $wallet->id,
            'balance' => 700
        ]);

        $this->assertDatabaseHas('transactions', [
            'wallet_id' => $wallet->id,
            'type' => 'withdrawal',
            'amount' => 300
        ]);
    }

    /**
     * Requirement: Withdraw Reject if insufficient balance.
     */
    public function test_withdraw_fails_insufficient_funds()
    {
        $wallet = Wallet::factory()->create(['balance' => 100]);

        $response = $this->postJson("/api/wallets/{$wallet->id}/withdraw", [
            'amount' => 200
        ]);

        $response->assertStatus(400); // Controller uses abort(400)

        // Balance remains unchanged
        $this->assertDatabaseHas('wallets', [
            'id' => $wallet->id,
            'balance' => 100
        ]);
    }

    /**
     * Requirement: Withdraw Must be idempotent.
     */
    public function test_withdraw_is_idempotent()
    {
        $wallet = Wallet::factory()->create(['balance' => 2000]);
        $key = 'unique-key-456';

        // First Request
        $this->postJson("/api/wallets/{$wallet->id}/withdraw", ['amount' => 500], ['Idempotency-Key' => $key])
            ->assertStatus(200)
            ->assertJson(['balance' => 1500]);

        // Second Request (Should be ignored)
        $this->postJson("/api/wallets/{$wallet->id}/withdraw", ['amount' => 500], ['Idempotency-Key' => $key])
            ->assertStatus(200)
            ->assertJson(['balance' => 1500]);

        // Verify balance
        $this->assertDatabaseHas('wallets', [
            'id' => $wallet->id,
            'balance' => 1500
        ]);
        
        // Verify only 1 transaction
        $this->assertDatabaseCount('transactions', 1);
    }
}
