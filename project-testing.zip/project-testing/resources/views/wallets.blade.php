<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Wallet Explorer</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600;700;900&display=swap" rel="stylesheet">
    <script src="https://cdn.tailwindcss.com"></script>
    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: {
                        sans: ['Outfit', 'sans-serif'],
                    },
                    colors: {
                        primary: '#6366f1',
                        secondary: '#ec4899',
                        dark: '#0f172a',
                        surface: '#1e293b',
                    },
                    animation: {
                        'float': 'float 6s ease-in-out infinite',
                        'pulse-slow': 'pulse 4s cubic-bezier(0.4, 0, 0.6, 1) infinite',
                    },
                    keyframes: {
                        float: {
                            '0%, 100%': { transform: 'translateY(0)' },
                            '50%': { transform: 'translateY(-20px)' },
                        }
                    }
                }
            }
        }
    </script>
    <style>
        body { font-family: 'Outfit', sans-serif; background-color: #0f172a; color: #f8fafc; }
        .glass-card {
            background: rgba(30, 41, 59, 0.7);
            backdrop-filter: blur(16px);
            border: 1px solid rgba(255, 255, 255, 0.08);
            box-shadow: 0 4px 30px rgba(0, 0, 0, 0.1);
        }
        .gradient-text {
            background: linear-gradient(135deg, #818cf8 0%, #f472b6 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        .shimmer {
            position: relative;
            overflow: hidden;
        }
        .shimmer::after {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255,255,255,0.05), transparent);
            transform: translateX(-100%);
            animation: shimmer 2s infinite;
        }
        @keyframes shimmer {
            100% { transform: translateX(100%); }
        }
    </style>
</head>
<body class="min-h-screen relative overflow-x-hidden selection:bg-indigo-500 selection:text-white" x-data="walletApp()">

    <!-- Decorative Background -->
    <div class="fixed inset-0 -z-20">
        <div class="absolute top-0 left-0 w-[500px] h-[500px] bg-primary/20 rounded-full blur-[120px] -translate-x-1/2 -translate-y-1/2"></div>
        <div class="absolute bottom-0 right-0 w-[500px] h-[500px] bg-secondary/20 rounded-full blur-[120px] translate-x-1/2 translate-y-1/2"></div>
    </div>

    <!-- NavBar -->
    <nav class="border-b border-white/5 bg-dark/50 backdrop-blur-md sticky top-0 z-50">
        <div class="container mx-auto px-6 h-20 flex items-center justify-between">
            <a href="/" class="flex items-center space-x-3 group">
                <div class="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-500 to-pink-500 flex items-center justify-center shadow-lg group-hover:shadow-indigo-500/50 transition-all duration-300">
                    <svg class="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z"></path></svg>
                </div>
                <span class="text-2xl font-bold">Wallet<span class="text-indigo-400">Explorer</span></span>
            </a>
            <div class="hidden md:flex items-center space-x-6">
                <div class="flex items-center space-x-2 px-3 py-1.5 rounded-full bg-white/5 border border-white/10">
                    <div class="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></div>
                    <span class="text-xs font-medium text-emerald-400">Live API Connection</span>
                </div>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <main class="container mx-auto px-6 py-12">
        
        <!-- Stats Row -->
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
            <!-- Total Wallets -->
            <div class="glass-card rounded-2xl p-6 relative overflow-hidden group">
                <div class="absolute right-0 top-0 p-4 opacity-10 group-hover:scale-110 transition-transform duration-500">
                    <svg class="w-24 h-24 text-indigo-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"></path></svg>
                </div>
                <p class="text-gray-400 text-sm font-medium uppercase tracking-wider mb-2">Total Wallets</p>
                <div class="flex items-baseline space-x-2">
                    <h3 class="text-4xl font-bold text-white" x-text="wallets.length">0</h3>
                    <span class="text-emerald-400 text-sm font-medium flex items-center">
                        <svg class="w-3 h-3 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 10l7-7m0 0l7 7m-7-7v18"></path></svg>
                        Active
                    </span>
                </div>
            </div>

            <!-- Total Volume -->
            <div class="glass-card rounded-2xl p-6 relative overflow-hidden group">
                <div class="absolute right-0 top-0 p-4 opacity-10 group-hover:scale-110 transition-transform duration-500">
                    <svg class="w-24 h-24 text-pink-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                </div>
                <p class="text-gray-400 text-sm font-medium uppercase tracking-wider mb-2">Total Balance (Est.)</p>
                <div class="flex items-baseline space-x-2">
                    <h3 class="text-4xl font-bold text-white" x-text="formatMoney(totalBalance())">0</h3>
                    <span class="text-indigo-300 text-sm">USD Eq.</span>
                </div>
            </div>

            <!-- Create New (Action) -->
            <button @click="showCreateModal = true" class="glass-card rounded-2xl p-6 relative overflow-hidden group hover:bg-white/5 transition-all outline-none focus:ring-2 ring-indigo-500">
                <div class="absolute inset-0 bg-gradient-to-br from-indigo-500/10 to-purple-500/10 opacity-0 group-hover:opacity-100 transition-opacity"></div>
                <div class="flex flex-col items-center justify-center h-full text-center">
                    <div class="w-12 h-12 rounded-full bg-gradient-to-r from-indigo-500 to-purple-500 flex items-center justify-center mb-3 shadow-lg group-hover:scale-110 transition-transform">
                        <svg class="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"></path></svg>
                    </div>
                    <span class="text-white font-semibold text-lg">Create New Wallet</span>
                    <span class="text-gray-400 text-sm mt-1">Setup in seconds</span>
                </div>
            </button>
        </div>

        <!-- Filters & Search -->
        <div class="flex flex-col md:flex-row justify-between items-center mb-8 space-y-4 md:space-y-0">
            <h2 class="text-2xl font-bold text-white flex items-center">
                <span class="w-2 h-8 rounded-full bg-indigo-500 mr-3"></span>
                Active Wallets
            </h2>
            <div class="relative w-full md:w-96">
                <input x-model="search" type="text" placeholder="Search by Owner Name..." 
                    class="w-full bg-dark/50 border border-white/10 rounded-xl py-3 pl-12 pr-4 text-gray-300 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-all placeholder-gray-600">
                <svg class="w-5 h-5 text-gray-500 absolute left-4 top-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path></svg>
            </div>
        </div>

        <!-- Wallets Grid -->
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6" x-show="!loading">
            <template x-for="wallet in filteredWallets" :key="wallet.id">
                <div class="glass-card rounded-2xl p-6 hover:translate-y-[-4px] transition-all duration-300 relative group">
                    <div class="flex justify-between items-start mb-6">
                        <div>
                            <span class="text-xs font-mono text-indigo-400 bg-indigo-500/10 px-2 py-1 rounded mb-2 inline-block">ID: #<span x-text="wallet.id"></span></span>
                            <h3 class="text-xl font-bold text-white truncate max-w-[200px]" x-text="wallet.owner_name"></h3>
                        </div>
                        <span class="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center border border-white/10 text-gray-400 font-bold text-xs" x-text="wallet.currency"></span>
                    </div>
                    
                    <div class="mb-6">
                        <p class="text-gray-400 text-xs uppercase tracking-wider mb-1">Available Balance</p>
                        <p class="text-3xl font-black gradient-text" x-text="formatMoney(wallet.balance)"></p>
                    </div>

                    <div class="flex space-x-3 pt-4 border-t border-white/5">
                        <button class="flex-1 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-sm font-medium transition-colors" @click="openDepositModal(wallet)">
                            Deposit
                        </button>
                        <button class="flex-1 py-2 rounded-lg bg-pink-600 hover:bg-pink-500 text-white text-sm font-medium transition-colors" @click="openTransferModal(wallet)">
                            Transfer
                        </button>
                        <button class="px-3 py-2 rounded-lg bg-red-600/20 hover:bg-red-600/40 text-red-400 hover:text-red-300 text-sm font-medium transition-colors" @click="confirmDelete(wallet)" title="Delete Wallet">
                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path></svg>
                        </button>
                    </div>
                </div>
            </template>
        </div>

        <!-- Toast Notification -->
        <div x-show="toast.visible" 
             x-transition:enter="transition ease-out duration-300"
             x-transition:enter-start="opacity-0 translate-y-2"
             x-transition:enter-end="opacity-100 translate-y-0"
             x-transition:leave="transition ease-in duration-200"
             x-transition:leave-start="opacity-100 translate-y-0"
             x-transition:leave-end="opacity-0 translate-y-2"
             class="fixed bottom-6 right-6 z-50">
            <div :class="{'bg-emerald-600': toast.type === 'success', 'bg-red-600': toast.type === 'error'}" 
                 class="px-6 py-4 rounded-xl shadow-2xl flex items-center space-x-3 text-white">
                <div x-show="toast.type === 'success'">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path></svg>
                </div>
                <div x-show="toast.type === 'error'">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path></svg>
                </div>
                <div>
                    <h4 class="font-bold" x-text="toast.title"></h4>
                    <p class="text-sm opacity-90" x-text="toast.message"></p>
                </div>
            </div>
        </div>

        <!-- Loading State -->
        <div x-show="loading" class="grid grid-cols-1 md:grid-cols-3 gap-6">
            <template x-for="i in 3">
                <div class="glass-card rounded-2xl p-6 h-64 shimmer"></div>
            </template>
        </div>

        <!-- Empty State -->
        <div x-show="!loading && filteredWallets.length === 0" class="text-center py-20">
            <div class="w-20 h-20 bg-white/5 rounded-full flex items-center justify-center mx-auto mb-6">
                <svg class="w-10 h-10 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 13V6a2 2 0 00-2-2H6a2 2 0 00-2 2v7m16 0v5a2 2 0 01-2 2H6a2 2 0 01-2-2v-5m16 0h-2.586a1 1 0 00-.707.293l-2.414 2.414a1 1 0 01-.707.293h-3.172a1 1 0 01-.707-.293l-2.414-2.414A1 1 0 006.586 13H4"></path></svg>
            </div>
            <h3 class="text-xl font-bold text-white mb-2">No Wallets Found</h3>
            <p class="text-gray-400">There are no wallets matching your criteria.</p>
        </div>

    </main>

    <!-- Create Wallet Modal -->
    <div x-show="showCreateModal" style="display: none;" class="fixed inset-0 z-50 overflow-y-auto" aria-labelledby="modal-title" role="dialog" aria-modal="true">
        <div class="flex items-center justify-center min-h-screen px-4 pt-4 pb-20 text-center sm:block sm:p-0">
            <div class="fixed inset-0 transition-opacity bg-dark/80 backdrop-blur-sm" @click="showCreateModal = false" x-transition.opacity></div>
            <div class="inline-block px-4 pt-5 pb-4 overflow-hidden text-left align-bottom transition-all transform bg-surface rounded-2xl border border-white/10 shadow-2xl sm:my-8 sm:align-middle sm:max-w-md sm:w-full sm:p-6 glass-card" x-transition.scale>
                <div>
                    <h3 class="text-xl font-bold leading-6 text-white mb-4">Create New Wallet</h3>
                    <div class="space-y-4">
                        <div>
                            <label class="block text-sm font-medium text-gray-400 mb-1">Owner Name</label>
                            <input x-model="newWallet.owner_name" type="text" class="w-full bg-dark/50 border border-white/10 rounded-lg p-3 text-white focus:ring-2 focus:ring-indigo-500 outline-none">
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-400 mb-1">Currency</label>
                            <select x-model="newWallet.currency" class="w-full bg-dark/50 border border-white/10 rounded-lg p-3 text-white focus:ring-2 focus:ring-indigo-500 outline-none">
                                <option value="USD">USD - US Dollar</option>
                                <option value="EUR">EUR - Euro</option>
                                <option value="GBP">GBP - British Pound</option>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="mt-6 flex justify-end space-x-3">
                    <button type="button" class="px-4 py-2 text-sm font-medium text-gray-300 hover:text-white transition-colors" @click="showCreateModal = false">Cancel</button>
                    <button type="button" class="px-6 py-2 text-sm font-medium text-white bg-gradient-to-r from-indigo-600 to-purple-600 rounded-lg shadow-lg hover:from-indigo-500 hover:to-purple-500 transition-all" @click="createWallet()">Create Wallet</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Transfer Modal -->
    <div x-show="showTransferModal" style="display: none;" class="fixed inset-0 z-50 overflow-y-auto" aria-labelledby="modal-title" role="dialog" aria-modal="true">
        <div class="flex items-center justify-center min-h-screen px-4 pt-4 pb-20 text-center sm:block sm:p-0">
            <div class="fixed inset-0 transition-opacity bg-dark/80 backdrop-blur-sm" @click="showTransferModal = false" x-transition.opacity></div>
            <div class="inline-block px-4 pt-5 pb-4 overflow-hidden text-left align-bottom transition-all transform bg-surface rounded-2xl border border-white/10 shadow-2xl sm:my-8 sm:align-middle sm:max-w-md sm:w-full sm:p-6 glass-card" x-transition.scale>
                <div>
                    <h3 class="text-xl font-bold leading-6 text-white mb-4">Transfer Funds</h3>
                    <div class="space-y-4">
                        <div class="p-3 bg-white/5 rounded-lg border border-white/5">
                            <span class="text-xs text-gray-400 uppercase">From</span>
                            <div class="font-bold text-white" x-text="transferData.from_name"></div>
                            <div class="text-xs text-indigo-300">Balance: <span x-text="formatMoney(transferData.from_balance)"></span></div>
                        </div>

                        <div>
                            <label class="block text-sm font-medium text-gray-400 mb-1">To Wallet</label>
                            <select x-model="transferData.to_wallet_id" class="w-full bg-dark/50 border border-white/10 rounded-lg p-3 text-white focus:ring-2 focus:ring-pink-500 outline-none">
                                <option value="">Select Recipient...</option>
                                <template x-for="wallet in otherWallets" :key="wallet.id">
                                    <option :value="wallet.id" x-text="`${wallet.owner_name} (#${wallet.id}) - ${wallet.currency}`"></option>
                                </template>
                            </select>
                        </div>

                        <div>
                            <label class="block text-sm font-medium text-gray-400 mb-1">Amount (in cents)</label>
                            <input x-model="transferData.amount" type="number" class="w-full bg-dark/50 border border-white/10 rounded-lg p-3 text-white focus:ring-2 focus:ring-pink-500 outline-none" placeholder="e.g. 1000 for $10.00">
                        </div>
                    </div>
                </div>
                <div class="mt-6 flex justify-end space-x-3">
                    <button type="button" class="px-4 py-2 text-sm font-medium text-gray-300 hover:text-white transition-colors" @click="showTransferModal = false">Cancel</button>
                    <button type="button" class="px-6 py-2 text-sm font-medium text-white bg-gradient-to-r from-pink-600 to-rose-600 rounded-lg shadow-lg hover:from-pink-500 hover:to-rose-500 transition-all cursor-pointer" @click="performTransfer()">Confirm Transfer</button>
                </div>
            </div>
        </div>
    </div>

    <script>
        function walletApp() {
            return {
                wallets: [],
                search: '',
                loading: true,
                showCreateModal: false,
                showTransferModal: false,
                newWallet: { owner_name: '', currency: 'USD' },
                transferData: { from_wallet_id: null, from_name: '', from_balance: 0, from_currency: '', to_wallet_id: '', amount: '' },
                toast: { visible: false, title: '', message: '', type: 'success' },

                async init() {
                    await this.fetchWallets();
                },

                showToast(title, message, type = 'success') {
                    this.toast = { visible: true, title, message, type };
                    setTimeout(() => { this.toast.visible = false }, 3000);
                },

                async fetchWallets() {
                    this.loading = true;
                    try {
                        const response = await fetch('/api/wallets');
                        this.wallets = await response.json();
                    } catch (error) {
                        console.error('Error fetching wallets:', error);
                        this.showToast('Error', 'Failed to load wallets', 'error');
                    } finally {
                        this.loading = false;
                    }
                },

                async createWallet() {
                    if(!this.newWallet.owner_name) return this.showToast('Validation', 'Owner Name Required', 'error');
                    
                    try {
                        const response = await fetch('/api/wallets', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify(this.newWallet)
                        });
                        
                        if(response.ok) {
                            this.showCreateModal = false;
                            this.newWallet.owner_name = '';
                            await this.fetchWallets(); // Refresh list
                            this.showToast('Success', 'Wallet created successfully');
                        } else {
                            this.showToast('Error', 'Failed to create wallet', 'error');
                        }
                    } catch (error) {
                        this.showToast('Error', 'Server Error', 'error');
                    }
                },

                openDepositModal(wallet) {
                    const amount = prompt(`Deposit amount for ${wallet.owner_name} (in cents):`);
                    if(amount && !isNaN(amount)) {
                        this.deposit(wallet.id, amount);
                    }
                },

                async deposit(id, amount) {
                    try {
                        const response = await fetch(`/api/wallets/${id}/deposit`, {
                            method: 'POST',
                            headers: { 
                                'Content-Type': 'application/json',
                                'Idempotency-Key': crypto.randomUUID()
                            },
                            body: JSON.stringify({ amount: parseInt(amount) })
                        });
                        if(response.ok) {
                            await this.fetchWallets();
                            this.showToast('Success', 'Deposit processed');
                        } else {
                            this.showToast('Error', 'Deposit Failed', 'error');
                        }
                    } catch (e) { console.error(e); }
                },

                openTransferModal(wallet) {
                    this.transferData = {
                        from_wallet_id: wallet.id,
                        from_name: wallet.owner_name,
                        from_balance: wallet.balance,
                        from_currency: wallet.currency,
                        to_wallet_id: '',
                        amount: ''
                    };
                    this.showTransferModal = true;
                },

                confirmDelete(wallet) {
                    if(wallet.balance > 0) {
                        return this.showToast('Warning', 'Cannot delete wallet with funds. Withdraw first.', 'error');
                    }
                    if(confirm(`Are you sure you want to delete ${wallet.owner_name}'s wallet?`)) {
                        this.deleteWallet(wallet.id);
                    }
                },

                async deleteWallet(id) {
                    try {
                        const response = await fetch(`/api/wallets/${id}`, {
                            method: 'DELETE'
                        });
                        const result = await response.json();
                        
                        if(response.ok) {
                            await this.fetchWallets();
                            this.showToast('Deleted', 'Wallet removed successfully');
                        } else {
                            this.showToast('Error', result.message || 'Delete failed', 'error');
                        }
                    } catch (e) {
                         this.showToast('Error', 'Could not delete wallet', 'error');
                    }
                },

                get otherWallets() {
                    // Filter out current wallet AND wallets with different currency
                    return this.wallets.filter(w => w.id !== this.transferData.from_wallet_id && w.currency === this.transferData.from_currency);
                },

                async performTransfer() {
                    if(!this.transferData.to_wallet_id || !this.transferData.amount) return this.showToast('Validation', 'Please fill all fields', 'error');
                    
                    try {
                        const response = await fetch('/api/transfers', {
                            method: 'POST',
                            headers: { 
                                'Content-Type': 'application/json',
                                'Idempotency-Key': crypto.randomUUID()
                            },
                            body: JSON.stringify({
                                from_wallet_id: this.transferData.from_wallet_id,
                                to_wallet_id: parseInt(this.transferData.to_wallet_id),
                                amount: parseInt(this.transferData.amount)
                            })
                        });

                        const result = await response.json();

                        if(response.ok) {
                            this.showTransferModal = false;
                            await this.fetchWallets();
                            this.showToast('Success', 'Transfer complete!');
                        } else {
                            this.showToast('Transfer Failed', result.message || 'Unknown error', 'error');
                        }
                    } catch (e) {
                        this.showToast('Error', 'Error processing transfer', 'error');
                    }
                },

                get filteredWallets() {
                    if(!this.search) return this.wallets;
                    return this.wallets.filter(w => w.owner_name.toLowerCase().includes(this.search.toLowerCase()));
                },

                totalBalance() {
                    return this.wallets.reduce((sum, w) => sum + w.balance, 0);
                },

                formatMoney(amount) {
                    return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(amount / 100); // Assuming cents
                }
            }
        }
    </script>
</body>
</html>
