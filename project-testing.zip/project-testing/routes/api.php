<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\WalletController;
use App\Http\Controllers\TransferController;

Route::get('/health', fn() => response()->json(['status' => 'ok']));

Route::post('/wallets', [WalletController::class, 'store']);
Route::get('/wallets', [WalletController::class, 'index']);
Route::get('/wallets/{id}', [WalletController::class, 'show']);
Route::delete('/wallets/{id}', [WalletController::class, 'destroy']);
Route::get('/wallets/{id}/balance', [WalletController::class, 'balance']);
Route::post('/wallets/{id}/deposit', [WalletController::class, 'deposit']);
Route::post('/wallets/{id}/withdraw', [WalletController::class, 'withdraw']);
Route::get('/wallets/{id}/transactions', [WalletController::class, 'transactions']);

Route::post('/transfers', [TransferController::class, 'transfer']);
