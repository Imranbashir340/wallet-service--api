<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Wallet;
use App\Models\Transaction;
use Illuminate\Support\Facades\DB;

class TransferController extends Controller
{
    public function transfer(Request $request)
    {
        $request->validate([
            'from_wallet_id'=>'required|integer|different:to_wallet_id',
            'to_wallet_id'=>'required|integer',
            'amount'=>'required|integer|min:1'
        ]);

        $idempotencyKey = $request->header('Idempotency-Key');

        $result = DB::transaction(function() use ($request, $idempotencyKey) {
            if ($idempotencyKey && Transaction::where('idempotency_key', $idempotencyKey)->exists()) {
                return ['message'=>'Transfer successful']; // Return same response for idempotent request
            }

            $source = Wallet::findOrFail($request->from_wallet_id);
            $target = Wallet::findOrFail($request->to_wallet_id);

            if ($source->currency !== $target->currency) abort(400, 'Currency mismatch');
            if ($source->balance < $request->amount) abort(400, 'Insufficient funds');

            $source->balance -= $request->amount;
            $target->balance += $request->amount;
            $source->save();
            $target->save();

            Transaction::create([
                'wallet_id'=>$source->id,
                'type'=>'transfer_debit',
                'amount'=>$request->amount,
                'related_wallet_id'=>$target->id,
                'idempotency_key'=>$idempotencyKey
            ]);

            Transaction::create([
                'wallet_id'=>$target->id,
                'type'=>'transfer_credit',
                'amount'=>$request->amount,
                'related_wallet_id'=>$source->id,
                'idempotency_key'=>$idempotencyKey
            ]);
            return ['message'=>'Transfer successful'];
        });

        return response()->json($result);
    }
}
