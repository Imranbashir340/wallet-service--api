<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Wallet;
use App\Models\Transaction;
use Illuminate\Support\Facades\DB;

class WalletController extends Controller
{
    public function index(Request $request)
    {
        $query = Wallet::query();
        if ($request->owner_name) $query->where('owner_name', $request->owner_name);
        if ($request->currency) $query->where('currency', $request->currency);
        return response()->json($query->get());
    }

    public function store(Request $request)
    {
        $request->validate([
            'owner_name'=>'required|string',
            'currency'=>'required|string|size:3'
        ]);

        $wallet = Wallet::create([
            'owner_name'=>$request->owner_name,
            'currency'=>$request->currency,
            'balance'=>0
        ]);

        return response()->json($wallet, 201);
    }

    public function show($id)
    {
        $wallet = Wallet::with('transactions')->findOrFail($id);
        return response()->json($wallet);
    }

    public function destroy($id)
    {
        $wallet = Wallet::findOrFail($id);
        if($wallet->balance > 0) {
            abort(400, 'Cannot delete wallet with positive balance');
        }
        $wallet->transactions()->delete(); // Optional: delete history or keep it? Usually keep, but for clean delete cascade.
        $wallet->delete();
        return response()->json(['message' => 'Wallet deleted successfully']);
    }

    public function balance($id)
    {
        $wallet = Wallet::findOrFail($id);
        return response()->json(['balance'=>$wallet->balance]);
    }

    public function deposit(Request $request, $id)
    {
        $request->validate([
            'amount'=>'required|integer|min:1'
        ]);
        $idempotencyKey = $request->header('Idempotency-Key');

        DB::transaction(function() use ($id, $request, $idempotencyKey) {
            $wallet = Wallet::findOrFail($id);
            if ($idempotencyKey && Transaction::where('idempotency_key', $idempotencyKey)->exists()) return;

            $wallet->balance += $request->amount;
            $wallet->save();

            Transaction::create([
                'wallet_id'=>$wallet->id,
                'type'=>'deposit',
                'amount'=>$request->amount,
                'idempotency_key'=>$idempotencyKey
            ]);
        });

        return $this->balance($id);
    }

    public function withdraw(Request $request, $id)
    {
        $request->validate([
            'amount'=>'required|integer|min:1'
        ]);
        $idempotencyKey = $request->header('Idempotency-Key');

        DB::transaction(function() use ($id, $request, $idempotencyKey) {
            $wallet = Wallet::findOrFail($id);
            if ($idempotencyKey && Transaction::where('idempotency_key', $idempotencyKey)->exists()) return;

            if ($wallet->balance < $request->amount) abort(400, 'Insufficient funds');

            $wallet->balance -= $request->amount;
            $wallet->save();

            Transaction::create([
                'wallet_id'=>$wallet->id,
                'type'=>'withdrawal',
                'amount'=>$request->amount,
                'idempotency_key'=>$idempotencyKey
            ]);
        });

        return $this->balance($id);
    }

    public function transactions(Request $request, $id)
    {
        $wallet = Wallet::findOrFail($id);
        $query = $wallet->transactions();

        if ($request->type) $query->where('type', $request->type);
        if ($request->from) $query->where('created_at', '>=', $request->from);
        if ($request->to) $query->where('created_at', '<=', $request->to);

        return response()->json($query->orderBy('created_at')->paginate(20));
    }
}
