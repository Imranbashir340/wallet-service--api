<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Wallet Service API</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600;700&display=swap" rel="stylesheet">
    <?php if(file_exists(public_path('build/manifest.json')) || file_exists(public_path('hot'))): ?>
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <?php else: ?>
        <script src="https://cdn.tailwindcss.com"></script>
        <script>
            tailwind.config = {
                theme: {
                    extend: {
                        fontFamily: {
                            sans: ['Outfit', 'sans-serif'],
                        },
                        colors: {
                            primary: '#6366f1',
                            secondary: '#a855f7',
                            dark: '#0f172a',
                            surface: '#1e293b',
                        }
                    }
                }
            }
        </script>
    <?php endif; ?>
    <style>
        body { font-family: 'Outfit', sans-serif; }
        .glass-card {
            background: rgba(30, 41, 59, 0.7);
            backdrop-filter: blur(12px);
            border: 1px solid rgba(255, 255, 255, 0.1);
        }
        .gradient-text {
            background: linear-gradient(135deg, #6366f1 0%, #a855f7 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
    </style>
</head>
<body class="bg-gray-900 text-gray-100 min-h-screen selection:bg-indigo-500 selection:text-white">

    <!-- Background Pattern -->
    <div class="fixed inset-0 -z-10 opacity-20">
        <div class="absolute top-0 left-0 w-96 h-96 bg-primary rounded-full mix-blend-multiply filter blur-3xl animate-blob"></div>
        <div class="absolute top-0 right-0 w-96 h-96 bg-secondary rounded-full mix-blend-multiply filter blur-3xl animate-blob animation-delay-2000"></div>
        <div class="absolute -bottom-8 left-20 w-96 h-96 bg-pink-600 rounded-full mix-blend-multiply filter blur-3xl animate-blob animation-delay-4000"></div>
    </div>

    <div class="container mx-auto px-4 py-12 max-w-6xl">
        
        <!-- Header -->
        <header class="flex justify-between items-center mb-16">
            <div class="flex items-center space-x-3">
                <div class="w-10 h-10 rounded-lg bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center shadow-lg shadow-indigo-500/30">
                    <svg class="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"></path></svg>
                </div>
                <span class="text-2xl font-bold tracking-tight">Wallet<span class="text-indigo-400">API</span></span>
            </div>
            <a href="/api/health" target="_blank" class="px-4 py-2 text-sm font-medium text-white bg-white/10 border border-white/10 rounded-full hover:bg-white/20 transition-all flex items-center space-x-2">
                <span class="w-2 h-2 rounded-full bg-green-400 animate-pulse"></span>
                <span>System Operational</span>
            </a>
        </header>

        <!-- Hero -->
        <main>
            <div class="text-center max-w-3xl mx-auto mb-20">
                <h1 class="text-5xl md:text-6xl font-bold mb-6 leading-tight">
                    Secure & Scalable <br/>
                    <span class="gradient-text">Financial Infrastructure</span>
                </h1>
                <p class="text-xl text-gray-400 mb-8 leading-relaxed">
                    A robust API service for managing digital wallets, processing transaction records, and executing atomic fund transfers with diverse currency support.
                </p>
                <div class="flex flex-wrap justify-center gap-4">
                    <a href="#endpoints" class="px-8 py-3 rounded-xl bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white font-semibold shadow-lg shadow-indigo-500/30 transition-all transform hover:-translate-y-0.5">
                        Explore Endpoints
                    </a>
                    <a href="/wallets" target="_blank" class="px-8 py-3 rounded-xl glass-card hover:bg-white/5 transition-all font-medium text-indigo-300">
                        View Live Wallets
                    </a>
                </div>
            </div>

            <!-- Features Grid -->
            <div class="grid md:grid-cols-3 gap-6 mb-24">
                <div class="glass-card p-8 rounded-2xl relative overflow-hidden group hover:bg-white/5 transition-all">
                    <div class="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
                        <svg class="w-24 h-24 text-indigo-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z"></path></svg>
                    </div>
                    <h3 class="text-xl font-bold mb-3 text-white">Wallet Management</h3>
                    <p class="text-gray-400 text-sm leading-relaxed">Create and manage multi-currency wallets with real-time balance updates and owner tracking.</p>
                </div>
                <div class="glass-card p-8 rounded-2xl relative overflow-hidden group hover:bg-white/5 transition-all">
                    <div class="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
                        <svg class="w-24 h-24 text-purple-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M8 7h12m0 0l-4-4m4 4l-4 4m0 6H4m0 0l4 4m-4-4l4-4"></path></svg>
                    </div>
                    <h3 class="text-xl font-bold mb-3 text-white">Atomic Transfers</h3>
                    <p class="text-gray-400 text-sm leading-relaxed">Safe money movement between wallets using database transactions to ensure consistency.</p>
                </div>
                <div class="glass-card p-8 rounded-2xl relative overflow-hidden group hover:bg-white/5 transition-all">
                    <div class="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
                        <svg class="w-24 h-24 text-pink-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                    </div>
                    <h3 class="text-xl font-bold mb-3 text-white">Idempotency</h3>
                    <p class="text-gray-400 text-sm leading-relaxed">Built-in duplicate protection for all financial operations using unique idempotency keys.</p>
                </div>
            </div>

            <!-- Endpoints Section -->
            <div id="endpoints" class="mb-20">
                <h2 class="text-3xl font-bold mb-8 flex items-center">
                    <svg class="w-8 h-8 mr-3 text-indigo-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"></path></svg>
                    API Endpoints
                </h2>

                <div class="space-y-4">
                    <!-- GET /wallets -->
                    <div class="glass-card p-5 rounded-xl flex flex-col md:flex-row md:items-center justify-between group hover:border-indigo-500/30 transition-colors">
                        <div class="flex items-center space-x-4 mb-4 md:mb-0">
                            <span class="px-3 py-1 rounded bg-blue-500/20 text-blue-400 text-xs font-bold font-mono">GET</span>
                            <span class="font-mono text-gray-300">/api/wallets</span>
                        </div>
                        <p class="text-sm text-gray-400">List all wallets with optional filtering</p>
                    </div>

                    <!-- GET /wallets/{id} -->
                    <div class="glass-card p-5 rounded-xl flex flex-col md:flex-row md:items-center justify-between group hover:border-indigo-500/30 transition-colors">
                        <div class="flex items-center space-x-4 mb-4 md:mb-0">
                            <span class="px-3 py-1 rounded bg-blue-500/20 text-blue-400 text-xs font-bold font-mono">GET</span>
                            <span class="font-mono text-gray-300">/api/wallets/{id}</span>
                        </div>
                        <p class="text-sm text-gray-400">Retrieve specific wallet details</p>
                    </div>

                    <!-- POST /wallets -->
                    <div class="glass-card p-5 rounded-xl flex flex-col md:flex-row md:items-center justify-between group hover:border-indigo-500/30 transition-colors">
                        <div class="flex items-center space-x-4 mb-4 md:mb-0">
                            <span class="px-3 py-1 rounded bg-emerald-500/20 text-emerald-400 text-xs font-bold font-mono">POST</span>
                            <span class="font-mono text-gray-300">/api/wallets</span>
                        </div>
                        <p class="text-sm text-gray-400">Create a new wallet</p>
                    </div>

                    <!-- POST /deposit -->
                    <div class="glass-card p-5 rounded-xl flex flex-col md:flex-row md:items-center justify-between group hover:border-indigo-500/30 transition-colors">
                        <div class="flex items-center space-x-4 mb-4 md:mb-0">
                            <span class="px-3 py-1 rounded bg-emerald-500/20 text-emerald-400 text-xs font-bold font-mono">POST</span>
                            <span class="font-mono text-gray-300">/api/wallets/{id}/deposit</span>
                        </div>
                        <p class="text-sm text-gray-400">Add funds (Idempotent)</p>
                    </div>

                    <!-- POST /transfers -->
                    <div class="glass-card p-5 rounded-xl flex flex-col md:flex-row md:items-center justify-between group hover:border-indigo-500/30 transition-colors">
                        <div class="flex items-center space-x-4 mb-4 md:mb-0">
                            <span class="px-3 py-1 rounded bg-emerald-500/20 text-emerald-400 text-xs font-bold font-mono">POST</span>
                            <span class="font-mono text-gray-300">/api/transfers</span>
                        </div>
                        <p class="text-sm text-gray-400">Transfer funds between wallets</p>
                    </div>
                </div>
            </div>

        </main>

        <!-- Footer -->
        <footer class="border-t border-gray-800 pt-8 text-center text-gray-500 text-sm">
            <p>&copy; <?php echo e(date('Y')); ?> Wallet Service API. Secure Financial Systems.</p>
        </footer>

    </div>

</body>
</html>
<?php /**PATH D:\xampp-new\htdocs\project-testing\resources\views/welcome.blade.php ENDPATH**/ ?>